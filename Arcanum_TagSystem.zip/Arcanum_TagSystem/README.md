Arcanum Tag-Driven World System
=================================

This package contains a tag-driven architecture for Roblox games using CollectionService.
Designers can tag objects using the Tag Editor or runtime calls, and the TagManager will
auto-apply behavior to tagged objects via handler modules.

Structure
---------
- ServerScriptService/
  - Modules/
    - TagManager.lua
    - Config.lua
    - Handlers/
      - TreasureChestHandler.lua
      - DamageZoneHandler.lua
  - InitTags.server.lua

How to use
----------
1. Place the ModuleScripts under ServerScriptService as shown in the structure.
2. Add `InitTags.server.lua` as a Server Script under ServerScriptService.
3. In Studio, tag models/parts using the Tag Editor (View -> Tag Editor). Use tags like:
   - TreasureChest
   - Lava
   - PoisonZone
4. Run the game. Tagged items will automatically have the behavior applied.

Notes & TODOs
-------------
- Handlers should run only on the server for authority (loot, damage, destroy).
- You can extend the `Handlers` folder with new behavior and register them in `InitTags.server.lua`.
- Add RemoteEvents in ReplicatedStorage for client feedback (UI, particles, sounds).
