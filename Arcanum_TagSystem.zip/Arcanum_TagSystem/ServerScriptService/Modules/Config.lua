-- Config.lua (ModuleScript)
local Config = {}

Config.LootMultipliers = {
    Default = 1.0,
    Event = 1.5,
}

-- Map of tagName -> handler module name (for reference)
Config.TagHandlers = {
    TreasureChest = "TreasureChestHandler",
    Lava = "DamageZoneHandler",
    PoisonZone = "DamageZoneHandler",
}

return Config
