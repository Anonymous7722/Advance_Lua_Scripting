-- TagManager.lua (ModuleScript)
local CollectionService = game:GetService("CollectionService")
local TagManager = {}

local handlers = {}
local applied = setmetatable({}, {__mode = "k"}) -- weak keys (instances)

local function safeRun(fn, ...)
    local ok, err = pcall(fn, ...)
    if not ok then
        warn("TagManager error:", err)
    end
end

function TagManager.registerHandler(tagName, handler)
    if handlers[tagName] then
        warn("Overwriting handler for tag:", tagName)
    end
    handlers[tagName] = handler

    -- apply to current instances with this tag
    for _, inst in ipairs(CollectionService:GetTagged(tagName)) do
        applied[inst] = applied[inst] or {}
        if not applied[inst][tagName] then
            applied[inst][tagName] = true
            safeRun(handler.setup, inst)
        end
    end

    -- listen for future instances
    CollectionService:GetInstanceAddedSignal(tagName):Connect(function(inst)
        applied[inst] = applied[inst] or {}
        if not applied[inst][tagName] then
            applied[inst][tagName] = true
            safeRun(handler.setup, inst)
        end
    end)

    -- listen for removed instances to teardown
    CollectionService:GetInstanceRemovedSignal(tagName):Connect(function(inst)
        if applied[inst] and applied[inst][tagName] then
            applied[inst][tagName] = nil
            if handler.teardown then
                safeRun(handler.teardown, inst)
            end
        end
    end)
end

function TagManager.hasTag(instance, tagName)
    return CollectionService:HasTag(instance, tagName)
end

function TagManager.addTag(instance, tagName)
    CollectionService:AddTag(instance, tagName)
end

function TagManager.removeTag(instance, tagName)
    CollectionService:RemoveTag(instance, tagName)
end

return TagManager
