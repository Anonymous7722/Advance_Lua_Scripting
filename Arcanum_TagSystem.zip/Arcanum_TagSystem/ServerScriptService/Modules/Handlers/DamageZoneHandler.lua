-- DamageZoneHandler.lua (ModuleScript)
local Players = game:GetService("Players")
local DAMAGE_PER_SECOND = 10

local DamageZone = {}

local function damageCharacter(character, dps)
    local humanoid = character and character:FindFirstChildOfClass("Humanoid")
    if humanoid and humanoid.Health > 0 then
        humanoid:TakeDamage(dps)
    end
end

function DamageZone.setup(part)
    if not part or not part:IsA("BasePart") then return end
    if part:GetAttribute("DamageConnected") then return end
    part:SetAttribute("DamageConnected", true)

    local touching = {}

    part.Touched:Connect(function(hit)
        local player = Players:GetPlayerFromCharacter(hit.Parent)
        if player and not touching[player] then
            touching[player] = true
            spawn(function()
                while touching[player] and player.Character and player.Character.Parent do
                    damageCharacter(player.Character, DAMAGE_PER_SECOND)
                    wait(1)
                end
            end)
        end
    end)

    part.TouchEnded:Connect(function(hit)
        local player = Players:GetPlayerFromCharacter(hit.Parent)
        if player then touching[player] = nil end
    end)
end

function DamageZone.teardown(part)
    -- optional cleanup
end

return DamageZone
