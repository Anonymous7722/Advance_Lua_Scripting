-- TreasureChestHandler.lua (ModuleScript)
local CollectionService = game:GetService("CollectionService")

local TreasureChestHandler = {}

local LootTable = {
    {item = "Gold", min = 10, max = 50, weight = 70},
    {item = "Potion", min = 1, max = 1, weight = 20},
    {item = "RareGem", min = 1, max = 1, weight = 10}
}

local function rollLoot()
    local total = 0
    for _, v in ipairs(LootTable) do total = total + v.weight end
    local r = math.random(1, total)
    local sum = 0
    for _, v in ipairs(LootTable) do
        sum = sum + v.weight
        if r <= sum then
            local amount = math.random(v.min, v.max)
            return v.item, amount
        end
    end
end

local function givePlayerLoot(player, itemName, amount)
    local ls = player:FindFirstChild("leaderstats")
    if ls and ls:FindFirstChild(itemName) then
        ls[itemName].Value = ls[itemName].Value + amount
    else
        if ls then
            local stat = Instance.new("IntValue")
            stat.Name = itemName
            stat.Value = amount
            stat.Parent = ls
        end
    end
end

function TreasureChestHandler.setup(chest)
    if not chest then return end
    if not chest:IsA("Model") then return end

    if chest:GetAttribute("ChestConnected") then return end
    chest:SetAttribute("ChestConnected", true)

    local prompt = chest:FindFirstChildOfClass("ProximityPrompt")
    if not prompt then
        local primary = chest.PrimaryPart or chest:FindFirstChildWhichIsA("BasePart")
        if primary then
            prompt = Instance.new("ProximityPrompt")
            prompt.ActionText = "Open"
            prompt.ObjectText = chest.Name
            prompt.HoldDuration = 0.6
            prompt.Parent = primary
        else
            warn("TreasureChestHandler: chest has no PrimaryPart or BasePart to attach a prompt to:", chest:GetFullName())
            return
        end
    end

    prompt.Triggered:Connect(function(player)
        local item, amt = rollLoot()
        givePlayerLoot(player, item, amt)
        -- TODO: visual feedback (particles/sound) via RemoteEvent
        chest:Destroy()
    end)
end

function TreasureChestHandler.teardown(chest)
    -- optional cleanup
end

return TreasureChestHandler
