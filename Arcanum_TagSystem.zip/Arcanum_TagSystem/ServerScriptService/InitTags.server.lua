-- InitTags.server.lua (Server Script)
local TagManager = require(script.Parent.Modules.TagManager)
local TreasureChestHandler = require(script.Parent.Modules.Handlers.TreasureChestHandler)
local DamageZoneHandler = require(script.Parent.Modules.Handlers.DamageZoneHandler)

-- Register handlers for tags
TagManager.registerHandler("TreasureChest", TreasureChestHandler)
TagManager.registerHandler("Lava", DamageZoneHandler)
TagManager.registerHandler("PoisonZone", DamageZoneHandler)
